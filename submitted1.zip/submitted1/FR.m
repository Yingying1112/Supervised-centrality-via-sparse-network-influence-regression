function [mFR,BIC]=FR(x0,y0)
    y=y0;y=y/std(y);    
   id=find(sum(x0,1)==0); x0(:,id)=[];
   
    [ss,ncov]=size(x0);                                                 %get ss and ncov
    x=x0;                                                               %get working x
    for j=1:ncov                                                        %standardize x
                                    
        x(:,j)=x(:,j)/std(x(:,j));                                      %variance = 1
    end
    X=x;Y=y;                                                            %backup x and y

    nStep=ceil(min(ncov,ss/4)); 
    nStep=min(nStep,100); %maximum forward step
    L2=zeros(nStep,1);mFR=[];ID=[1:ncov];                               %initialization
    for k=1:nStep                                                       %do for each step
         L2(k)=norm(y);        
        XL2=sum(x.^2,1)';                                               %Xj's L2 norm squared
        r=abs(x'*y)./XL2;                                               %absolute partial corr
        id=find(max(r)==r);id=id(1);                                    %find best predictor
        ak=ID(id);                                                      %find the best predictor
        mFR=[mFR,ak];                                                   %include next predictor
        xj=x(:,id);if norm(xj)>0; xj=xj/norm(xj); end;                  %make norm(xj)=1
        x(:,id)=[];ID(id)=[];      %eliminate xj 
        y=y-xj*(xj'*y);x=x-xj*(xj'*x);                                  %do profiling
                                            %current RSS
    end
    
    BIC=2*log(L2)+[1:nStep]'*(log(ss)+2*log(ncov))/ss;                  %NOTE: L2^2=RSS
    
    pos=find(min(BIC)==BIC)-1;                                          %best stopping position
    if pos>0                                                            %if nontrivial model detected
        mFR=mFR([1:pos]);                                               %get FR model
    else                                                                %if no relevant var. detected
        mFR=[];                                                         %set init. model = null
    end