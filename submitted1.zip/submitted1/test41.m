
% this code used to obtain the result for the first block of Table 5 
clear all;                                                                            %clear the working space
nsimu=100
fid = fopen('Result_41.txt','wt');                                                                          %This is simulation iter number

opt = [5000,7500,15000]

rand('state',0);randn('state',0);                                                                     %This is the predictor dimension
%r1=floor(N^0.25);
r1=10
rho1 = unifrnd(0.5,1,r1,1);

Record=zeros(nsimu,length(opt));
CF0=[]; TPR0=[];  RMSE=[];ND=[];
CP=[];FPR0=[];FP0=[];UF0=[];
%for k=1:length(opt)                                                                  %fix different sample size
for k=1:3                                    
    N=opt(k);
    p2=0; cf=0;
    TPR=zeros(nsimu,1); FPR=[];
    RMSE0=zeros(nsimu,1);  Density=zeros(nsimu,1);
    FP=[];UF=[];
    %This is the predictor dimensio
    for i=1:nsimu
        i;
        [A,Y,ID0,density,edges]=simulator21(N,rho1,r1);
        ID_0=[1:N];ID_0(ID0)=[];
        t1=clock;
        id=find(sum(A)>10);
        id=sort(id);k0=floor(N/log(N));
        if length(id)>k0 id=id(1:k0); end
        ID2=[1:N];ID2(id)=[];
        Y0=Y(ID2);
        X_i= Y(id);
        W0=A(ID2,id);
        X0=W0*diag(X_i);
        [ID,BIC]=FR(X0,Y0);
        t2=clock;
        ID=id(ID);
        ID=sort(ID);
        
        %time=etime(t2,t1);
        Density(i)=density;                                                  %record the result: density
        
        ID2=[1:N];ID2(ID)=[];
        
        Y0=Y(ID2); X_i= Y(ID); W0=A(ID2,ID);  X0=W0*diag(X_i);
        
       
        
        rhohat=inv(X0'*X0)*(X0'*Y0);
        rhohat0=zeros(N,1); rhohat0(ID)=rhohat;
        rho_1=zeros(N,1);rho_1(ID0)=rho1;
        rmse=norm(rhohat0-rho_1);
        
        RMSE0(i)=rmse;
        C2=intersect(ID, ID0);
        tpr=length(C2)/r1;
        TPR(i)=tpr;
        
        if length(C2)==r1; p2=p2+1;
        end
        if (length(C2)==r1)& length(ID)==r1; cf=cf+1;
        end
        
         uf=r1-length(C2); if uf>0;  UF=[UF,uf];end
        
        
        C3=intersect(ID, ID_0);
        
        if (length(C3)~=0)
            fpr=length(C3)/length(ID);
            fp=length(C3);
        end
        if length(C3)>0 FPR=[FPR,fpr];FP=[FP,fp];
        else FPR=[FPR,0]; end
    end
    if length(UF)>0 UF0=[UF0;mean(UF)]; else UF0=[UF0;0]; end
    ND=[ND;mean(Density)*100];
    CP=[CP;p2/nsimu]
    RMSE=[RMSE;median(RMSE0)]
    TPR0=[TPR0;mean(TPR)]
    CF0=[CF0;cf/nsimu];
    if length(FP)>0; FP0=[FP0; mean(FP)];else FP0=[FP0; 0];end
    FPR0=[FPR0;mean(FPR)];
end


Result=[TPR0,FPR0,CF0,RMSE,ND]
fprintf(fid,'Result= %8.3f:\n',Result);

fclose(fid);