% SBM simulator
function [A,Y,ID0,density,edges]=simulator22(N,rho1,r1);                                                        
  K=5;
  p1=ones(1,K)/K;                                             
  Z=mnrnd(1,p1,N);                                              
  P=ones(K,K)/(N^0.8);
  P(logical(eye(K))) =0.5/(N^0.8);
  B=Z*P*Z';
  pos=find(rand(N,N)<B);
   A=zeros(N,N); A(pos)=1;

A1=sum(A);
[idd,pos]=sort(-A1);
%k0=floor(N/log(N));
k0=floor(N^(2/3)); 
k=randperm(k0,r1);

ID0=pos(k);ID0=sort(ID0);

A0=A(:,ID0);
A_n=sum(A0,2);                                                         
S=find(A_n==0); k1=length(S); 

for k0=1:k1
    S1 = randperm(r1);
   if S(k0)~=S1(1)  A(S(k0),ID0(S1(1)))=1;
   else A(S(k0),ID0(S1(2)))=1; end
end

edges=sum(sum(A));                                                     % compute for edges
density=edges/(N*(N-1)); 

 D=diag(rho1);
Y11=normrnd(0,1,r1,1);
 Y11=inv(eye(r1)-A(1:r1,1:r1)*diag(D))*(Y11(1:r1)+5*ones(r1,1));
%   ak=find(abs(Y11)<=0.5);
%  Y11(ak)=unifrnd(0.5,1.5);
e2=normrnd(0,1,N-r1,1);
 ID_0=[1:N];ID_0(ID0)=[];
Y2=A(ID_0,ID0)*D*Y11+e2; 
Y=zeros(N,1); Y(ID0)=Y11;
Y(ID_0)=Y2;