% obtain the result  for Table 6 

clear all;                                                                            %clear the working space
nsimu=100;
fid = fopen('Result_real1.txt','wt');                                                                          %This is simulation iter number

rand('state',0);randn('state',0);  
N=2275;
r1=8; n=N-r1; 

CF0=[]; TPR0=[];  RMSE0=[];
FPR0=[];FP0=[];UF0=[];
                                                                %fix different sample size                             
 for d=1:3  
   cf=0;  p2=0; 
  TPR=zeros(nsimu,1); RMSE=zeros(nsimu,1);  
   FPR=[]; FP=[];UF=[];
   
  rand('state',0);randn('state',0); 
  rho1 = unifrnd(0.5,1,r1,1);
 for i=1:nsimu
     [A,Y,ID0,density,edges]=simulator_real1(N,rho1,r1,d); 
    ID_0=[1:N];ID_0(ID0)=[];
       A1=sum(A); [idd,pos]=sort(-A1);
       id=find(sum(A)>20);  
      pos=pos(1:length(id));
       k0=floor(N^(2/3));
     
       if length(id)>k0 pos=pos(1:k0); end
       id=pos;
       ID2=[1:N];ID2(id)=[];
       Y0=Y(ID2);
        X_i= Y(id);
       A0=A(ID2,id);
       X0=A0*diag(X_i);
       [ID,mFR0,BIC]=FR(X0,Y0);
       ID=id(ID); ID=sort(ID);                    
       ID2=[1:N];ID2(ID)=[];  
     Y0=Y(ID2); X_i= Y(ID); W0=A(ID2,ID);  X0=W0*diag(X_i); 
     rhohat=inv(X0'*X0)*(X0'*Y0);
     rhohat0=zeros(N,1); rhohat0(ID)=rhohat;
     rho_1=zeros(N,1);rho_1(ID0)=rho1;
     rmse=norm(rhohat0-rho_1);
     RMSE(i)=rmse;
     
   
    C2=intersect(ID, ID0);
        tpr=length(C2)/r1;
        TPR(i)=tpr;
        
    if length(C2)==r1; p2=p2+1; end
       
     if (length(C2)==r1)& length(ID)==r1; cf=cf+1;end
 
       uf=r1-length(C2); if uf>0;  UF=[UF,uf];end;
   
   
   C3=intersect(ID, ID_0);
        
        if (length(C3)~=0)
            fpr=length(C3)/length(ID);
            fp=length(C3);
        end
        if length(C3)>0 FPR=[FPR,fpr];FP=[FP,fp];
        else FPR=[FPR,0]; end     
end
 
    if length(UF)>0 UF0=[UF0;mean(UF)]; else UF0=[UF0;0]; end
  
    RMSE0=[RMSE0;median(RMSE)]
    TPR0=[TPR0;mean(TPR)]
    CF0=[CF0;cf/nsimu];
    if length(FP)>0; FP0=[FP0; mean(FP)];else FP0=[FP0; 0];end
    FPR0=[FPR0;mean(FPR)];
 end

Result=[TPR0,FPR0,CF0,RMSE0]
fprintf(fid,'Result= %8.3f:\n',Result);

fclose(fid);