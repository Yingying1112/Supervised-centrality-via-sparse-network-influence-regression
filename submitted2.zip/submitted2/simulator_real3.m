function [A,Y,ID0,density,edges]=simulator_real3(N,rho1,r1,d); 
%Setting 3  in Section 4.3
YY=csvread('df.csv',1,5);

YY0=YY;
YY0(:,d)=log(YY(:,d)+1);
Y=YY0(:,d);

AA=csvread('adj2.csv',1,0);
n=N-r1;
[obs,obs1]=size(AA);
A=sparse(AA(:,1),AA(:,2),ones(obs,1),N,N);
A(logical(eye(N))) = 0;
A=full(A);


                                                                      
A1=sum(A);
[idd,pos]=sort(-A1); 

k0=floor(N^(2/3));  id=find(sum(A)>20); 
k0=min(k0,length(id));
k=randperm(k0,r1);
ID0=pos(k);ID0=sort(ID0);

A0=A(:,ID0);
A_n=sum(A0,2);                                                         
S=find(A_n==0); k1=length(S); 

for k0=1:k1
    S1 = randperm(r1);
   if S(k0)~=S1(1)  A(S(k0),ID0(S1(1)))=1;
   else A(S(k0),ID0(S1(2)))=1; end
end


edges=sum(sum(A));                                                     % compute for edges
density=edges/(N*(N-1)); 
D=diag(rho1);

Y11=Y(ID0);
e2=normrnd(0,1,N-r1,1);
 ID_0=[1:N];ID_0(ID0)=[];
Y2=A(ID_0,ID0)*D*Y11+e2; 
Y=zeros(N,1); Y(ID0)=Y11;
Y(ID_0)=Y2;